<script context="module" lang="ts">
	export const load = async () => {
		return {
			status: 302,
			redirect: '/default-channel/EN_US/'
		};
	};
</script>
